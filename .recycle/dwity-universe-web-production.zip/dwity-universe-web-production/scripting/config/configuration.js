
upstreamAPIURL="http://localhost:8888";

$(document).ready(function () {

});
