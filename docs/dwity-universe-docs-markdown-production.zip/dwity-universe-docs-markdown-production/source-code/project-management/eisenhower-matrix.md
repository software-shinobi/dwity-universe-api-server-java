# Eisenhower Priority Matrix
Ref: [https://todoist.com/productivity-methods/eisenhower-matrix](https://todoist.com/productivity-methods/eisenhower-matrix)

| |URGENT |NOT URGENT |
|:---|---:|---:|
**IMPORTANT**|DO IT :`Immediate Deadlines`|SCHEDULE IT :`Future Deadlines` |
**NOT IMPORTANT**|DELEGATE IT :`You Are Not Required` |DELETE IT :`Distraction, No Real Value`  |
