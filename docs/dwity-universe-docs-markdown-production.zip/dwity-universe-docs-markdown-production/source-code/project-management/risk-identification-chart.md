# Risk Identification Chart

| Control Element | What is likely to go wrong? | How and when will I know? | What will I do about it? |
|-----------------|-----------------------------|---------------------------|--------------------------|
| Quality         |                             |                           |                          |
| Cost            |                             |                           |                          |
| Timeliness      |                             |                           |                          |
